
#Maryam aref -219032944
seq <- seq(0, 20)
print("sequence of numbers from 0 to 20 ")
print(seq)


Mean <- mean(150:234)
print("mean of sequencsqe of numbers from 150 to 234 ")
print(Mean)


sum1 <- sum(11:90)
print("Sum of sequence of numbers from 150 to 234 ")
print(sum1)




