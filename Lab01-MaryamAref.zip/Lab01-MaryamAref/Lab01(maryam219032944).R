#Maryam aref -219032944
Calculator1 <- function(arg_1, arg2){
  
  mul = arg_1*arg2
  sum = arg_1+arg2
  exp1 = arg_1^arg2
  
  print("The exponent is ")
  print(exp1)
  print("The muliplicaton is ")
  print(mul)
  print("The Sum is ")
  print(sum)
}




